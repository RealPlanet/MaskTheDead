# Mask the dead

### Wanna add more risk to Comedy & Tragedy? 
#### Add more challenge to the masks and a fun new way to mess with your friends

If a mask is in close proximity of a dead body it might possess it and wreak avong in your team! Drop a body next to a mask if you feel like messing with your team! Beware that dying with the mask in your inventory can be the end of a profitable run!

Mod can be customized within the config file.

By default:
 * Possession chance: 100%
 * Possession range: 10 units

### **1.0.0**
- Initial version